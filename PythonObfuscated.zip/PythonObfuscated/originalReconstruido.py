from itertools import cycle
import base64
from Crypto.Cipher import AES

class AESCipher(object):
    def __init__(self, key):
        self.bs = AES.block_size
        self.key = key.encode('utf-8')  # Convertir la clave a bytes
        self.cipher = AES.new(self.key, AES.MODE_ECB)

    def encrypt(self, raw):
        raw = self._pad(raw.encode('utf-8'))
        encrypted = self.cipher.encrypt(raw)
        encoded = base64.b64encode(encrypted)
        return str(encoded, 'utf-8')

    def decrypt(self, raw):
        decoded = base64.b64decode(raw)
        decrypted = self.cipher.decrypt(decoded)
        return self._unpad(decrypted).decode('utf-8')

    def _pad(self, s):
        return s + (self.bs - len(s) % self.bs) * chr(self.bs - len(s) % self.bs).encode('utf-8')

    @staticmethod
    def _unpad(s):
        return s[:-ord(s[len(s)-1:])]

class sCRCDlpYibqMekCnUWAszaUKNQLKRZWYTqoGuKtdieZYbYpqawbvzctGoHiZKFNE:
    afPRCiboWLLbSyxcisEchTVnYRTZWMVUOEniqaCAVSfoIbsvPflzYQidemuwegXY = 'Canis familiaris'

    def __init__(self, name, age):
        self.name = name
        self.age = age

    def MfurkuTqsFaffburapZCsDgQnWMKYSPtjEVmIwXQGzpvdIFWZiGaeaVTRvFaFhqw(self):
        return f'\n{self.name} is {self.age} years old.'

    def jlFcuXbYsxdxZGTVqeBtWDlkpIuQKNGDUEAzgeirLbYYWJolCQBiXYKawiHDucxi(self, sound):
        name = base64.b64decode(self.name).decode('ascii')
        return f'{name} says {sound}'

qdObyQqZXtRNDNotFDnuiYKaGnCVyVEcbrHPTRRHLYQWKURhFcEtoeYPXFYVWfkv = 'uB3GbV45fdz6YMWf'
cipher = AESCipher(qdObyQqZXtRNDNotFDnuiYKaGnCVyVEcbrHPTRRHLYQWKURhFcEtoeYPXFYVWfkv)
soKbGZSnHReMnKNyCYVXlTBSpTUqdXrqyTNhxAFSmBVpKGAcwcOmhyZnkGQSvizo = sCRCDlpYibqMekCnUWAszaUKNQLKRZWYTqoGuKtdieZYbYpqawbvzctGoHiZKFNE('Y29tb3R1', '3')
sAFyQvdgdbLerfDjfAWcroKuYfHLoZKwAFbOYgaZJRAwNqMVbqcoiWXuTBqvWFCO = 'XPDfIRDa09PzMVDkb3Y068rmkVC1gZWh0yGE59RPj3U='

print('Welcome to the password recovery tool.\n')
QRCfkqOERbslBaoIcaGtkVanmTSxHkJdwXHBnwvAefpAyJDyImSAOkdLmbwksIlM = input("What is your pet's name?\n")
print('\nComparing strings...')
if QRCfkqOERbslBaoIcaGtkVanmTSxHkJdwXHBnwvAefpAyJDyImSAOkdLmbwksIlM == base64.b64decode('Y29tb3R1').decode('ascii'):
    print('\nCongratulations! Right answer:\n\t' + soKbGZSnHReMnKNyCYVXlTBSpTUqdXrqyTNhxAFSmBVpKGAcwcOmhyZnkGQSvizo.jlFcuXbYsxdxZGTVqeBtWDlkpIuQKNGDUEAzgeirLbYYWJolCQBiXYKawiHDucxi(cipher.decrypt(sAFyQvdgdbLerfDjfAWcroKuYfHLoZKwAFbOYgaZJRAwNqMVbqcoiWXuTBqvWFCO)))
else:
    print('\nWrong answer!:\n\tTRY HARDER!')
