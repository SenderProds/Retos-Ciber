# Importamos las bibliotecas necesarias
import base64
import argparse
from Crypto.Cipher import AES

# Definimos la función de descifrado
def decrypt(key, encrypted):
    # Creamos un objeto AES con la clave proporcionada en modo ECB
    cipher = AES.new(key.encode('utf-8'), AES.MODE_ECB)
    
    # Decodificamos el texto cifrado de base64 y lo desciframos
    decrypted = cipher.decrypt(base64.b64decode(encrypted))
    
    # Eliminamos el padding y convertimos el resultado a string
    return decrypted.rstrip(decrypted[-1:]).decode('utf-8')

# Configuramos el parser de argumentos
parser = argparse.ArgumentParser(description='Descifrar un texto cifrado con AES en modo ECB.')
parser.add_argument('key', type=str, help='La clave AES utilizada para cifrar el mensaje')
parser.add_argument('encrypted', type=str, help='El texto cifrado en base64 que se desea descifrar')

# Parseamos los argumentos
args = parser.parse_args()

# Desciframos el mensaje para obtener la flag
flag = decrypt(args.key, args.encrypted)

# Imprimimos la flag
print(flag)
